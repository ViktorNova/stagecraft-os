/* Defines needed to use Xlib from non-imake projects */
#ifndef XTHREADS
#define XTHREADS
#endif
#ifndef XUSE_MTSAFE_API
#define XUSE_MTSAFE_API
#endif
